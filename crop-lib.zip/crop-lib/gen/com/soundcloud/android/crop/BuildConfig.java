/** Automatically generated file. DO NOT MODIFY */
package com.soundcloud.android.crop;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}